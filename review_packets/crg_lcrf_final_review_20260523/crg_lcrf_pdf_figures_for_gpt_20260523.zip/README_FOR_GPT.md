# CRG/LCRF PDF Figure Review Package

This package is prepared for reviewing and improving `crg_lcrf_cn_paper_draft.md`.

The figure files are PDF-only. No PNG or SVG files are included.

## Folder Structure

```text
figures_main_pdf/
  fig2_nature_data_and_crg_retrieval.pdf
  fig3_nature_crg_support_corruption.pdf
  fig4_nature_lcrf_counterfactual_delta.pdf
  fig5_nature_lcrf_same_query_posterior.pdf

figures_candidate_pdf/
  alternate_fig1_problem_concept_evidence_gap.pdf
  alternate_fig2_crg_lcrf_framework.pdf
  alternate_fig3_evidence_chain.pdf
  fig2_core3_data_and_crg_retrieval_final.pdf
  fig3_core3_support_corruption_final.pdf
  fig5_core3_lcrf_same_query_posterior_final.pdf
  figS_crg_local_route_cases_core3.pdf
  figS_crg_subgroup_support_dependence_core3.pdf
  figS_lcrf_specific_student_timeline_core3.pdf
  figS_lcrf_state_source_audit_core3.pdf
```

## Recommended Main Figures

1. `fig2_nature_data_and_crg_retrieval.pdf`
   - Purpose: data phenomenon plus CRG route retrieval.
   - Claim: core datasets have concept evidence gaps, and train-stage CRG routes retrieve held-out transitions better than self/random controls.
   - Suggested paper position: data phenomenon or experiment overview.

2. `fig3_nature_crg_support_corruption.pdf`
   - Purpose: prediction-level CRG support perturbation.
   - Claim: support dependence is dataset-dependent. Assist_17 is the cleanest evidence-gap case; assist_09 supports support-dependence; Junyi is weak for prediction-level corruption.
   - Suggested paper position: CRG support perturbation analysis.
   - Do not overclaim that CRG evidence is stronger than arbitrary graphs on all datasets.

3. `fig4_nature_lcrf_counterfactual_delta.pdf`
   - Purpose: LCRF learner-state counterfactual.
   - Claim: assist_09 and assist_17 show learner-state dependence; Junyi should be reported as weak for LCRF.
   - Suggested paper position: LCRF counterfactual section.

4. `fig5_nature_lcrf_same_query_posterior.pdf`
   - Purpose: same-query posterior mechanism case.
   - Claim: under fixed CRG support, different learners receive different posterior route weights and prediction shifts.
   - Suggested paper position: LCRF case-study section or main text visual mechanism evidence.

## Candidate / Appendix Figures

- `alternate_fig1_problem_concept_evidence_gap.pdf`
  - Alternative problem figure for the introduction.
- `alternate_fig2_crg_lcrf_framework.pdf`
  - Alternative method architecture figure.
- `alternate_fig3_evidence_chain.pdf`
  - Alternative evidence-chain figure.
- `fig2_core3_data_and_crg_retrieval_final.pdf`
  - Earlier version of data + retrieval figure.
- `fig3_core3_support_corruption_final.pdf`
  - Earlier version of support corruption figure.
- `fig5_core3_lcrf_same_query_posterior_final.pdf`
  - Earlier version of same-query posterior figure.
- `figS_*`
  - Appendix candidates only. Use them if they make the mechanism clearer; otherwise omit.

## Writing Boundaries

When improving the draft, keep these boundaries:

- CRG is the global route/support constructor.
- LCRF is the learner-conditioned posterior filter over fixed CRG support.
- Sequence transition should be written as empirical learning route, not prerequisite.
- Do not claim mathematical sufficient/necessary proof.
- Do not claim every dataset proves every mechanism equally.
- Junyi is strong for data phenomenon and CRG route retrieval, but weak for LCRF.
- Assist_17 is the strongest prediction-level CRG support-dependence case.
- Assist_09 is the balanced dataset and supports both retrieval and LCRF counterfactual evidence.
- Avoid defensive phrasing in the main text; express limitations as dataset regimes or appendix analysis.
