# Prompt for GPT to Optimize `crg_lcrf_cn_paper_draft.md`

Please review the Chinese manuscript draft `crg_lcrf_cn_paper_draft.md` together with the PDF figures in this package. Your task is to improve the manuscript structure, figure placement, captions, and experimental narrative. Do not invent new experiments or numbers.

## What to Review

1. Read the manuscript draft first.
2. Inspect the four recommended main figures in `figures_main_pdf/`.
3. Inspect optional candidate figures in `figures_candidate_pdf/`.
4. Decide which figures should be placed in the main text, which should go to appendix, and which should be omitted.

## Required Output

Please output:

1. A revised figure plan:
   - Figure number
   - Filename
   - Target manuscript section
   - Claim supported
   - Whether it should be main text or appendix

2. Concrete edits to `crg_lcrf_cn_paper_draft.md`:
   - Which section should be rewritten
   - Where each figure should be inserted
   - Suggested caption text
   - Suggested transition paragraph before/after each figure

3. A claim-boundary audit:
   - Which claims are strongly supported
   - Which claims should be softened
   - Which datasets should be used for each claim

4. A final paper narrative:
   - One-sentence core problem
   - One-sentence CRG contribution
   - One-sentence LCRF contribution
   - One-sentence experiment evidence chain

## Recommended Main Figures

- `fig2_nature_data_and_crg_retrieval.pdf`
  - Data evidence-gap cards plus CRG retrieval.
  - Use to support data phenomenon and CRG route sufficiency.

- `fig3_nature_crg_support_corruption.pdf`
  - Support corruption curves.
  - Use to support dataset-dependent support dependence, not universal evidence superiority.

- `fig4_nature_lcrf_counterfactual_delta.pdf`
  - Learner-state counterfactual.
  - Use to support LCRF state-dependence on assist_09 and assist_17; mark Junyi as weak.

- `fig5_nature_lcrf_same_query_posterior.pdf`
  - Same-query posterior case.
  - Use to show that LCRF personalizes posterior weights within fixed CRG support.

## Important Boundaries

- Do not write that sequence transition is prerequisite.
- Do not write that CRG is mathematically sufficient and necessary.
- Do not write that LCRF strongly works on Junyi.
- Do not write that CRG evidence beats arbitrary graphs on every dataset.
- Do not claim student-ID shortcut is completely excluded.
- Do not use internal phrases such as "weak evidence" in a defensive way; rewrite as dataset-regime differences.

## Desired Writing Style

Make the paper read like a normal top-conference cognitive diagnosis manuscript:

- State the problem directly.
- Present CRG as global auditable support construction.
- Present LCRF as support-constrained personalization.
- Use figures as evidence, not as internal audit reports.
- Keep caveats precise but not defensive.
